#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> //Functions to determine the type contained in character data


#define AVAIRABLE 0
#define RESERVED 1
#define DEBUG 0

int isValidMenu(char []);



int str_to_int(char *str) {
    int n = strlen(str);
    int sum = 0, i, val;
    for (i = n - 1, val = 1; i >= 0; i--) {
        if (str[i] >= '0' && str[i] <= '9') {
            sum += (str[i] - '0') * val;

            val *= 10;
        }
    }
    return sum;
}

typedef struct {
    int id;
    char name[100];
    char type[100];
    int price, row, col;

} Theater;

typedef struct {
    Theater *theater;
    int times[10];
    int time_size;
    int reserve[10][100][100];
} TimeTable;

typedef struct {
    int id;
    char name[100];
    char type[100];
    int length;
    TimeTable timeTable[10];
    int timeTable_size;
} Movie;


Movie movies[100];
int movie_size = 0;

Theater theaters[100];
int theater_size = 0;

Movie *get_movie(int id) {
    int i;
    for (i = 0; i < movie_size; i++) {
        if (movies[i].id == id) {
            return &movies[i];
        }
    }
    return NULL;
}

Theater *get_theater(int id) {
    int i;
    for (i = 0; i < theater_size; i++) {
        if (theaters[i].id == id) {
            return &theaters[i];
        }
    }
    return NULL;
}

void add_movie(int id, char name[100], char type[100], int length) {
    Movie movie;
    movie.id = id;
    strcpy(movie.name, name);
    strcpy(movie.type, type);
    movie.length = length;
    movie.timeTable_size = 0;
    int i, j, row, col;
    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
            for (row = 0; row < 10; row++) {
                for (col = 0; col < 10; col++) {
                    movie.timeTable[i].reserve[j][row][col] = AVAIRABLE;
                }
            }
        }
    }
    movies[movie_size] = movie;
    movie_size++;
}

void add_theater(int id, char name[100], char type[100], int price, int row, int col
) {
    Theater theater;
    theater.id = id;
    strcpy(theater.name, name);
    strcpy(theater.type, type);
    theater.price = price;
    theater.row = row;
    theater.col = col;
    theaters[theater_size] = theater;
    theater_size++;


}

void add_timeTable(int movie_id, int theater_id, int times[10], int time_size) {
    Movie *movie = get_movie(movie_id);
    //(*movie).name is movie -> name
    Theater *theater = get_theater(theater_id);
    TimeTable timeTable;
    timeTable.theater = theater;
    timeTable.time_size = 0;
    int i;
    for (i = 0; i < time_size; i++) {
        timeTable.times[timeTable.time_size] = times[i];
        timeTable.time_size++;
    }
    movie->timeTable[movie->timeTable_size] = timeTable;
    movie->timeTable_size++;
}

void display_movie(Movie m) {
    printf(" _____________________________________________________________\n");
    printf("|%d,%-20s(%-4s)  %3d min                        |\n", m.id, m.name, m.type, m.length);
    printf("|_____________________________________________________________|\n");

}

void display_movies() {
    int i;
    for (i = 0; i < movie_size; i++) {
        display_movie(movies[i]);
    }
}

void display_theater(Theater t) {
    printf(" ______________________________________________________________\n");
    printf("| Movie id: %d | %-10s(%-4s) %3d Bath  |%3d row %3d column |\n", t.id, t.name, t.type, t.price, t.row,
           t.col);
    printf("|_____________|____________________________|___________________|\n");


}

void display_theaters() {
    int i;
    for (i = 0; i < theater_size; i++) {
        display_theater(theaters[i]);
    }
}

void display_timetable(int movie_id) {
    Movie *m = get_movie(movie_id);
    int i;
    int j;
    for (i = 0; i < m->timeTable_size; i++) {
        display_theater(*(m->timeTable[i].theater));
        for (j = 0; j < m->timeTable[i].time_size; j++) {
            int t = m->timeTable[i].times[j];
            int h = t / 100;
            int m = t % 100;
            printf("    \n|%02d:%02d PM|\n        ", h, m);
        }
        printf("\n");
    }
}

void display_seat(int movie_id, int theater_id, char timetable[10]) {
    Movie *m = get_movie(movie_id);
    int i;
    int j;
    int row;
    int col;
    for (i = 0; i < m->timeTable_size; i++) {
        if (theater_id == m->timeTable[i].theater->id) {
            for (j = 0; j < m->timeTable[i].time_size; j++) {
                if (str_to_int(timetable) == m->timeTable[i].times[j]) {
                    printf("  ");
                    for (col = 0; col < m->timeTable[i].theater->col; col++) {
                        printf(" %3d ", col + 1);
                    }
                    printf("\n");
                    for (row = 0; row < m->timeTable[i].theater->row; row++) {
                        printf("%c ", row + 'A');
                        for (col = 0; col < m->timeTable[i].theater->col; col++) {
                            if (m->timeTable[i].reserve[j][row][col] == AVAIRABLE) {
                                printf("[   ]");
                            } else {
                                printf("[ X ]");
                            }
                        }
                        printf("\n");
                    }
                }
            }
        }
    }

}

int reserve_seat(int movie_id, int theater_id, char timetable[10], char row, int col) {
    Movie *m = get_movie(movie_id);
    int i;
    int j;
    for (i = 0; i < m->timeTable_size; i++) {
        if (theater_id == m->timeTable[i].theater->id) {
            for (j = 0; j < m->timeTable[i].time_size; j++) {
                if (str_to_int(timetable) == m->timeTable[i].times[j]) {
                    if (m->timeTable[i].reserve[j][row - 'A'][col - 1] == AVAIRABLE) {
                        m->timeTable[i].reserve[j][row - 'A'][col - 1] = RESERVED;
                        return 1;
                    } else {
                        return 0;
                    }
                }
            }
        }
    }
}

int get_seat_price(int movie_id, int theater_id, char timetable[10]) {
    Movie *m = get_movie(movie_id);
    int i;
    int j;
    for (i = 0; i < m->timeTable_size; i++) {
        if (theater_id == m->timeTable[i].theater->id) {
            for (j = 0; j < m->timeTable[i].time_size; j++) {
                if (str_to_int(timetable) == m->timeTable[i].times[j]) {
                    return m->timeTable[i].theater->price;
                }
            }
        }
    }
}


void load_data_movies() {
    char MOVIE_FILE[100] = "data/movies.txt";
    FILE *fmovie = fopen(MOVIE_FILE, "r");
    char line[100];

    int id = 0;
    char name[100], type[100];
    int length = 0;

    while (!feof(fmovie)) {
        fgets(line, 100, fmovie);
        if (strlen(line) < 2) {
            continue;
        }
        char delimiter[2] = ",";
        char *token = strtok(line, delimiter);
        id = str_to_int(token);
        token = strtok(NULL, delimiter);
        strcpy(name, token);
        token = strtok(NULL, delimiter);
        strcpy(type, token);
        token = strtok(NULL, delimiter);
        length = str_to_int(token);
        add_movie(id, name, type, length);

    }

}


void load_data_theater() {
    char THEATER_FILE[100] = "data/theater.txt";
    FILE *ftheater = fopen(THEATER_FILE, "r");
    char line[100];
    int i;
    while (!feof(ftheater)) {
        fgets(line, 100, ftheater);
        int id = 0;
        char name[100];
        char type[100];
        int price, row, col;
        char delimiter[2] = ",";
        char *token = strtok(line, delimiter);
        id = str_to_int(token);
        token = strtok(NULL, delimiter);
        strcpy(name, token);
        token = strtok(NULL, delimiter);
        strcpy(type, token);
        token = strtok(NULL, delimiter);
        price = str_to_int(token);
        token = strtok(NULL, delimiter);
        row = str_to_int(token);
        token = strtok(NULL, delimiter);
        col = str_to_int(token);
        add_theater(id, name, type, price, row, col);

    }
}

void load_data_timetable() {
    char TIMETABLE_FILE[100] = "data/timetable.txt";
    FILE *ftimetable = fopen(TIMETABLE_FILE, "r");
    char line[100];
    int i;
    while (!feof(ftimetable)) {
        fgets(line, 100, ftimetable);
        int movie_id;
        int theater_id;
        int times[10];
        int time_size = 0;
        char delimiter[2] = ",";
        char *token = strtok(line, delimiter);
        movie_id = str_to_int(token);
        token = strtok(NULL, delimiter);
        theater_id = str_to_int(token);
        token = strtok(NULL, delimiter);
        while (token != NULL) {
            times[time_size] = str_to_int(token);
            time_size++;
            token = strtok(NULL, delimiter);
        }
        add_timeTable(movie_id, theater_id, times, time_size);
    }
}


void load_data() {
    load_data_movies();
    load_data_theater();
    load_data_timetable();
}

void print_ticket(int movie_id, int theater_id, char timetable[10], char row, int col) {
    printf(">> PRINTING RESERVATION TICKET << \n");
    if (reserve_seat(movie_id, theater_id, timetable, row, col)) {
        int price = get_seat_price(movie_id, theater_id, timetable);
        if (price <= 0 || price >= 300) {price = 0;}
        Movie *m = get_movie(movie_id);
        Theater *t = get_theater(theater_id);
        printf(" __________________________________________________\n");
        printf("|%-25s (%s) | %-11s  |\n", m->name,timetable, t->name);
        printf("|_________________________________________________|\n");
        printf("|SEAT : %c%d | Price : %d                           |\n", row, col, price);
        printf("|_________________________________________________|\n");


    } else {
        printf("This seat is not available\n");
    }

}

int main() {
    load_data();

    char temp_command[10];
    int command;
    while (1) {

        do {
            printf(" _______________________________");
            printf("\n|----- Select Your Command -----|\n");
            printf("|-------------------------------|\n");
            printf("|1 - List movies                |\n");
            printf("|2 - List Time Table            |\n");
            printf("|3 - Show Seat                  |\n");
            printf("|4 - Reserved                   |\n");
            printf("|0 - Quit                       |\n");
            printf("|_______________________________|\n");
            printf("\n");

            printf("Please select the option above :\n");
            gets(temp_command);
            if (isValidMenu(temp_command) == 1 && strlen(temp_command) == 1) {
                command = atoi(temp_command);
                break;
            }
        } while (1);


        if (!command) {
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            printf("! ! ! !  ! ! End of program ! ! ! !  ! ! ! ! ! CLICK RUN IF YOU WANT TO CONTINUE! ! ! !  ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! \n");
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");

            exit(1);
        }

        if (command == 1) {
            display_movies();
        } else if (command == 2) {
            int movieid;
            char temp_movieid[10];

            do {
                printf(" _________________________________________\n");
                printf("|           input movies id               |\n");
                printf("|_________________________________________|\n");
                printf("\n");
                printf("Please Enter movie id :");

                gets(temp_movieid);
                if (isValidMenu(temp_movieid) == 1 && strlen(temp_movieid) == 1) {
                    movieid = atoi(temp_movieid);

                    display_timetable(movieid);
                    break;
                }
            } while (1);

        } else if (command == 3) {
            int movieid;
            char temp_movieid[10];
            char temp_theater[10];
            int theaterid;
            char timetable[10];

            do {
                printf("Input Movie id:");
                gets(temp_movieid);
                if (isValidMenu(temp_movieid) == 1 && strlen(temp_movieid) == 1) {
                    movieid = atoi(temp_movieid);
                    break;
                }
            } while (1);


            do {
                printf("Input theater id:");
                gets(temp_theater);

                if (isValidMenu(temp_theater) == 1 && strlen(temp_theater) == 1) {
                    theaterid = atoi(temp_theater);
                    break;
                }
            } while (1);

            do {
                printf("Input Time:");
                gets(timetable);
                if (DEBUG) {
                    printf("\n isTimeValid ? : %d\n", isValidTime(timetable));
                }
                if (isValidTime(timetable) == 1 && strlen(timetable) == 5) {
                    display_seat(movieid, theaterid, timetable);
                    break;
                }
            } while (1);


        } else if (command == 4) {
            char temp2[10];
            char *temp;
            char *position;
            char timetable[10];
            char letteralphabet[20] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
                                       'Q', 'R', 'S', 'T'};
            char numalphabet[10][2] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
            char row;
            int col;
            int movieid;
            char temp_movieid[10];
            char temp_theater[10];
            int theaterid;

            position = ((char *) malloc(100));
            temp = ((char *) malloc(10));

            do {
                printf("Input Movie id:");
                gets(temp_movieid);
                if (isValidMenu(temp_movieid) == 1 && strlen(temp_movieid) == 1) {
                    movieid = atoi(temp_movieid);
                    break;
                }
            } while (1);

            do {
                printf("Input theater id:");
                gets(temp_theater);

                if (isValidMenu(temp_theater) == 1 && strlen(temp_theater) == 1) {
                    theaterid = atoi(temp_theater);
                    break;
                }
            } while (1);

            do {
                printf("Input Time:");
                gets(timetable);
                if (DEBUG) {
                    printf("\n isTimeValid ? : %d\n", isValidTime(timetable));
                }
                if (isValidTime(timetable) == 1 && strlen(timetable) == 5) {
                    display_seat(movieid, theaterid, timetable);
                    break;
                }
            } while (1);

            int ch = 1;

            while (ch) {
                printf("Input Position:");
                gets(position);
                for (int i = 0; i < 20; i++) {
                    for (int j = 0; j < 10; j++) {
                        char tempL[2];
                        tempL[0] = letteralphabet[i];
                        tempL[1] = '\0';
                        strcpy(temp, tempL);
                        strcat(temp, numalphabet[j]);
                        if (strcmp(temp, position) == 0) {
                            int row_int = atoi(&position[1]);
                            print_ticket(movieid, theaterid, timetable, position[0], row_int);
                            ch = 0;
                            free(position);
                            free(temp);
                            break;

                        }


                    }
                }

            }

        }
    }

}

int isValidMenu(char command[]) { //
    for (int i = 0; i < sizeof(*command); i++) {
        if (isalpha(command[i]) != 0) {
            return 0;
        }
    }
    return 1;
}

int isValidTime(char time[]) {
    if (strlen(time) != 5) {
        return 0;
    }

    if (time[2] != ':') {
        return 0;
    }
    if (DEBUG) {
        puts(time);
        for (int j = 0; j < strlen(time); ++j) {
            printf("isdigit time[%d] = %d\n", j, isdigit(time[j]));
        }
    }


    for (int i = 0; i < strlen(time); i++) {
        if (i == 2) {
            continue;
        }

        if (isdigit(time[i]) == 0) {
            return 0;
        }
    }
    return 1;
}





